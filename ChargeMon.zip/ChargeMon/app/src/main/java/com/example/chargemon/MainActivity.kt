package com.example.chargemon

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var capEdit: EditText
    private lateinit var targetEdit: EditText
    private val h = Handler(Looper.getMainLooper())
    private var alerted = false
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val p = getSharedPreferences("p", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
            setBackgroundColor(Color.parseColor("#101418"))
        }
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.GRAY); textSize = 13f }
        fun field(v: String) = EditText(this).apply {
            setText(v); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        capEdit = field(p.getInt("cap", 5000).toString())
        targetEdit = field(p.getInt("target", 100).toString())
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; setPadding(0, 30, 0, 0) }

        root.addView(label("Battery capacity (mAh)")); root.addView(capEdit)
        root.addView(label("Alarm at battery % (sound when reached)")); root.addView(targetEdit)
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() {
        super.onPause(); h.removeCallbacks(tick)
        getSharedPreferences("p", MODE_PRIVATE).edit()
            .putInt("cap", capEdit.text.toString().toIntOrNull() ?: 5000)
            .putInt("target", targetEdit.text.toString().toIntOrNull() ?: 100).apply()
    }

    private fun update() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val scale = i.getIntExtra("scale", 100).coerceAtLeast(1)
        val level = i.getIntExtra("level", 0) * 100 / scale
        val volt = i.getIntExtra("voltage", 0) / 1000.0
        val temp = i.getIntExtra("temperature", 0) / 10.0
        val plug = i.getIntExtra("plugged", 0)
        val status = i.getIntExtra("status", 0)
        val health = i.getIntExtra("health", 0)
        val charging = plug != 0 &&
            (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)

        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val raw = abs(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
        val ma = if (raw > 20000) raw / 1000.0 else raw.toDouble() // devices differ: µA or mA
        val watts = volt * ma / 1000.0

        val cap = (capEdit.text.toString().toIntOrNull() ?: 5000).coerceAtLeast(500)
        val target = (targetEdit.text.toString().toIntOrNull() ?: 100).coerceIn(1, 100)

        val src = when (plug) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC wall charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB (PC / port)"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Not plugged in"
        }

        var eta = "-"
        if (charging && ma > 50 && level < 100) {
            val remain = cap * (100 - level) / 100.0
            val taper = if (level >= 80) 1.6 else 1.1 // charging slows near full
            val mins = (remain / ma * taper * 60).toInt()
            eta = "${mins / 60}h ${mins % 60}m (estimate)"
        }

        val c = ma / cap // C-rate
        val verdict = when {
            !charging -> "Plug in a charger to test it."
            temp >= 45 -> "BAD: battery too hot (${temp}°C). Unplug / cool it."
            ma < 50 -> "Not charging (or battery is full)."
            c < 0.15 -> "WEAK charger: very slow. Fine for overnight, poor for daily use."
            c < 0.5 -> "OK charger: gentle on the battery."
            c <= 1.2 -> "GOOD charger: healthy fast charge."
            else -> "VERY FAST: great if the phone supports it, watch the heat."
        }

        info.text = """
            Battery: $level %   (${statusName(status)})
            Voltage: ${"%.2f".format(volt)} V
            Current: ${ma.toInt()} mA
            Power: ${"%.1f".format(watts)} W
            Temp: $temp °C   Health: ${healthName(health)}
            Source: $src

            Time to full: $eta

            Charger check:
            $verdict
            (C-rate ${"%.2f".format(c)})
        """.trimIndent()

        if (plug != 0 && level >= target) {
            if (!alerted) {
                alerted = true
                RingtoneManager.getRingtone(
                    this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ).play()
            }
        } else alerted = false
    }

    private fun statusName(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
        else -> "Unknown"
    }

    private fun healthName(s: Int) = when (s) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        else -> "Unknown"
    }
}
